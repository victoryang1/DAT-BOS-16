# hello4.py
def hello():
    print "Hello, world!"

def test():
    hello()

if __name__ == '__main__': test()