# hello.py
print "Hello, world!"