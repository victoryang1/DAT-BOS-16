# Exercise 8.26
# Author: Noah Waterfield Price

import Deck2


