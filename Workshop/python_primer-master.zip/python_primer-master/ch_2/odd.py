# Exercise 2.3
# Author: Noah Waterfield Price

n = 12
i = 0
while i < int(round(n / 2.)):
    print 2 * i + 1,
    i += 1

"""
Sample run:
python odd_list2.py
1 3 5 7 9 11
"""
