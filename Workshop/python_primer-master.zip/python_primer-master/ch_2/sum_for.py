# Exercise 2.13
# Author: Noah Waterfield Price

s = 0
k = 1
M = 100
for k in range(1, M + 1):
    s += 1. / k
print s

"""
Sample run:
python sum_for.py
5.18737751764
"""
