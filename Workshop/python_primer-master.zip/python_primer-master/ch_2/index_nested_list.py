# Exercise 2.16
# Author: Noah Waterfield Price

q = [['a', 'b', 'c'], ['d', 'e', 'f'], ['g', 'h']]

print q[0][0]  # a
print q[1]  # ['d', 'e', 'f']
print q[2][1]  # h
print q[1][0]  # d

"""
Sample run:
python index_nested_list.py
a
['d', 'e', 'f']
h
d
"""
