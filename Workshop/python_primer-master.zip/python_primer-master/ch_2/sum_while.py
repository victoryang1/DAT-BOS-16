# Exercise 2.12
# Author: Noah Waterfield Price

s = 0
k = 1
M = 100
while k <= M:
    s += 1. / k
    k += 1
print s

"""
Sample run:
python sum_while.py
5.18737751764
"""
