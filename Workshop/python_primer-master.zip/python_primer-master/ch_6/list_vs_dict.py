# Exercise 6.9
# Author: Noah Waterfield Price

t1 = {}
t1[0] = -5     # Dictionary key: value assignment
t1[1] = 10.5

"""
t2 = []
t2[0] = -5     # List look up by index (obviously not found)
t2[1] = -10.5
"""

# Need to assign initial list values, for example:
t2 = [0]*2
t2[0] = -5     # List look up by index (obviously not found)
t2[1] = -10.5
