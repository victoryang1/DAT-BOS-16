# Exercise 6.23print �Hello, World!�"""Sample run:python office.py  File "/Users/Noah/dev/apospwp/ch_6/office.py", line 2SyntaxError: Non-ASCII character '\xd4' in file /Users/Noah/dev/apospwp/ch_6/office.py on line 2, but no encoding declared; see http://www.python.org/peps/pep-0263.html for details"""    # Author: Noah Waterfield Price

