# Exercise 1.1
# Author: Noah Waterfield Price

answer = 1 + 1
print answer

"""
Sample run:
python 1plus1.py
2
"""
