# Exercise 1.9b
# Author: Noah Waterfield Price

v0 = 3  # m/s
t = 1  # s
a = 2  # m/s
s = v0 * t + 0.5 * a * t ** 2
print s

"""
Sample run:
python acceleration.py
4.0
"""
