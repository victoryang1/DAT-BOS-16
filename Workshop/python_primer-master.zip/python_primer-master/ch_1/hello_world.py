# Exercise 1.2
# Author: Noah Waterfield Price

print "Hello, World!"

"""
Sample run:
python hello_world.py
Hello, World!
"""
