# Exercise 1.7
# Author: Noah Waterfield Price

from math import sin

x = 1
print 'sin(%g)=%g' % (x, sin(x))

"""
Sample run:
python find_errors.py
sin(1)=0.841471
"""
