# Exercise 1.9a
# Author: Noah Waterfield Price

from math import sin, cos, pi

x = pi / 4
val1 = sin(x) ** 2 + cos(x) ** 2
print val1

"""
Sample run:
python sin2_plus_cos2.py
1.0
"""
