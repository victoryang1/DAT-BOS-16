# Exercise 3.12
# Author: Noah Waterfield Price

def hw1():
    return 'Hello, World!'


def hw2():
    print 'Hello, World!'


def hw3(s1, s2):
    print s1 + ', ' + s2


print hw1()
hw2()
hw3('Hello', 'World!')

"""
Sample run:
python hw_func.py
Hello, World!
Hello, World!
Hello, World!
"""
